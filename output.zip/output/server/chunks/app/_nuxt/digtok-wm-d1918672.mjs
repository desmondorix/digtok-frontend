import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_1 = "" + buildAssetsURL("digtok-wm.fadc93fd.png");

export { _imports_1 as _ };
//# sourceMappingURL=digtok-wm-d1918672.mjs.map
