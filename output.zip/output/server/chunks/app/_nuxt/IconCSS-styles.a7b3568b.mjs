const IconCSS_vue_vue_type_style_index_0_scoped_5ee01813_lang = "span[data-v-5ee01813]{background-color:currentColor;display:inline-block;-webkit-mask-image:var(--5fa51ebc);mask-image:var(--5fa51ebc);-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-size:100% 100%;mask-size:100% 100%;vertical-align:middle}";

const IconCSSStyles_a7b3568b = [IconCSS_vue_vue_type_style_index_0_scoped_5ee01813_lang, IconCSS_vue_vue_type_style_index_0_scoped_5ee01813_lang];

export { IconCSSStyles_a7b3568b as default };
//# sourceMappingURL=IconCSS-styles.a7b3568b.mjs.map
