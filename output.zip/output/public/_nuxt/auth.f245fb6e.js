import{E as r,G as o,H as a}from"./entry.52f653c0.js";const i=r((e,s)=>{const t=o();if(e!=="/"&&!t.id)return a("/")});export{i as default};
