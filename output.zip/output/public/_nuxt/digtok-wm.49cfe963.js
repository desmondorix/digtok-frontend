import"./entry.52f653c0.js";const o=""+new URL("digtok-wm.fadc93fd.png",import.meta.url).href;export{o as _};
